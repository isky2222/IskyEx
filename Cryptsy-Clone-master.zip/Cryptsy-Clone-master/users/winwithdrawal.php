<?php
echo "<center><h2 style='color: #228B22;'>Withdrawal success</h2></center>";
unset($_SESSION["erreurs"]);

?>