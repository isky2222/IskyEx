<div class="navbar navbar-default navbar-blue">
      <div class="container ">
        <div class="navbar-header"> 
          <a  href="/index.php"><img src="/img/cryptomaniac10.jpg" alt="" width="250" height="50"></a>
        </div> 
          <ul class="nav navbar-nav pull-right ">
            <li><a href="/users/register.php"><div class="avatar"><img src="/img/register-icon-16.gif" alt="">&nbsp;&nbsp;Register New Account</div></a></li>
            <li><a href="/users/login.php"><div class="avatar"><img src="/img/userslogin-crypto-maniac.png" alt="">&nbsp;&nbsp;Login</div></a></li>

          </ul>  
      </div>
    </div>