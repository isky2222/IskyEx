<meta charset='utf-8'> 
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="description" content="Trade Crypto Currencies Safely ,Exchange Bitcoin ,Litecoin,Dogecoin and many other">
<link rel="author" href="https://twitter.com/_cryptomaniac/">
<meta http-equiv="Content-Language" content="en">
<meta name="keywords" content="Trading,Exchange,Crypto,Currency,Currencie,Bitcoin,Litecoin,Dogecoin,Anoncoin,alphacoin,americancoin,Argentum,auroracoin,battlecoin,bbqcoin,betacoin,bitbar,bitgem,bottlecaps">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0-rc2/css/bootstrap-glyphicons.css" rel="stylesheet">
<link href="/css/style.css?v=<?php echo time();?>" rel="stylesheet" media="screen"> 
<link href="/css/jquery.dataTables.css" rel="stylesheet" media="screen">
<link rel="stylesheet" href="/css/jquery-ui-1.10.4.custom.min.css">
<link href="/css/prettyCheckable.css" rel="stylesheet" media="screen"> 
<link type="text/css" media="screen" rel="stylesheet" href="/js/colorbox.css?version=20130925b" />
<link type="text/css" rel="stylesheet" href="/css/dropit.css" />
<link href='https://fonts.googleapis.com/css?family=Roboto:400,700,500,300' rel='stylesheet' type='text/css'> 
<link rel="stylesheet" href="/css/badger.min.css?rev=2" type="text/css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>
<link href="/css/form.authy.min.css" media="screen" rel="stylesheet" type="text/css">
<link href="/css/jquery.jui_alert.css" media="screen" rel="stylesheet" type="text/css">
<link rel="icon" type="image/gif" href="/img/favicon1.gif" >
<link rel="shortcut icon" type="image/gif" href="/img/favicon1.gif" />
<link type="text/css" href="/css/jquery.ui.chatbox.css?rev=5" rel="stylesheet" />
<script type="text/javascript" src="/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="/js/jquery-ui-1.10.4.custom.min.js"></script>
<script type="text/javascript" src="/js/jquery.colorbox.js?version=20130801"></script>
<script type="text/javascript" src="/js/jquery.ui.dialog.min.js"></script>
<script type="text/javascript" src="/js/bg.pos.js"></script>
<script src="/js/tabs.pack.js" type="text/javascript"></script>
<script type="text/javascript" src="/js/highstock.js"></script>
<script type="text/javascript" src="/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="/js/jquery.loadmask.min.js"></script>
<script type="text/javascript" src="/js/jquery.base64.min.js"></script>
<script src='/js/jquery.json-2.2.min.js'></script>
<script src="/js/select2.js"></script>
<script src="/js/prettyCheckable.js"></script>
<script src="/js/bootstrap.js"></script>
<script src="/js/iscroll.js"></script>
<script src="/js/custom.js?rev=4"></script>
<script type="text/javascript" src="/js/dropit.js"></script>
<script src="/js/form.authy.min.js" type="text/javascript"></script>
<script type="text/javascript" src="/js/jquery.ui.chatbox.js?rev=3"></script>
<script type="text/javascript" src="/js/noty/packaged/jquery.noty.packaged.min.js?rev=2"></script>
<script type="text/javascript" src="/js/myNoty.js"></script>




<?php 
date_default_timezone_set('America/New_York'); 
?>