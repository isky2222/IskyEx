# Cryptsy-Clone

100 % Free Cryptsy Clone

Please consider to make a donation if you using my script

Bitcoin:  1FL1qQiz4HUEakqa9PH5VGH7Ustaqe1stY

Litecoin: LNAXMC2UKpey1ZgD4QXs26jJPTdYj3xryu

Copyright (c) 2014-2015 Adytech Developer Copyright

Pierre Demarque

Installation Instruction
you need php 5.4 and follow instruction http://pastebin.com/CaFXQMQ7

i do installation service + securisation if you need

contact:
adytech2010 at the giant search engine  .com



#License

Cryptsy-Clone is released under the terms of the MIT license. See COPYING for more information or see http://opensource.org/licenses/MIT.
